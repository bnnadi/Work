$(document).ready(function(){
    
    $('').addClass('hilite');

});