$(document).ready(function(){
    
   var json = [
       {
           title: 'school of rock',
           href: 'http://schoolofrock.com'           
       },
       {
           title: 'place of stuff',
           href: 'http://fullsail.com'          
       },
       {
           title: 'house of horrors',
           href: 'http://online.fullsail.com'          
       },
       {
           title: 'home',
           href: 'http://jsfiddle.com'           
       }       
   ];           



});