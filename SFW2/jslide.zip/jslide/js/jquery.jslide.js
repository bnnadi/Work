/*
	jSlide Plugin
	Version: 2.0
	Framework: jQuery 1.8+
	Author: Fullsail Javascript/jQuery Development Team
	===================++++++=================
	USAGE
	--------------
	<div id="carousel">
		<ul>
			<li>Item</li>
		</ul>
	</div>
	
	$('#carousel').jslide();
	
	OPTIONS
	--------------
	
*/